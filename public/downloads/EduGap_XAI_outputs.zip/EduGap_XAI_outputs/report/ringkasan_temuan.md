# Ringkasan Temuan EduGap-XAI

## Data dan preprocessing
- Panel 190 baris (38 provinsi x 5 tahun); 12 baris DOB Papua 2021-2023 terdeteksi sebagai salinan provinsi induk dan dikeluarkan, menyisakan 178 baris analisis inti.
- 56 sel diimputasi sesuai aturan (tahun sebelumnya, tahun sesudahnya, lalu provinsi induk); 0 di antaranya berada di analisis inti.
- Simpangan baku APS 16-18 berubah +49.2% (2021-2025) pada semua provinsi valid, tetapi -0.7% pada 32 provinsi dengan batas konsisten.

## RQ1 Spatial autocorrelation
- Moran's I APS 16-18: 2021: 0.116 (p=0.086), 2022: 0.126 (p=0.071), 2023: 0.116 (p=0.082), 2024: 0.112 (p=0.077), 2025: 0.184 (p=0.022).
- Tahun dengan autokorelasi signifikan (p < 0,05): [2025].
- Cluster LL 2025: PAPUA PEGUNUNGAN, PAPUA SELATAN; cluster HH 2025: BALI, JAWA TENGAH, JAWA TIMUR, SUMATERA UTARA.
- Bivariate Moran terkuat 2025: APS vs Penduduk Miskin (%) tetangga, I = -0.374 (p = 0.000).

## RQ2 Pattern mining
- 20 kandidat aturan, 7 lolos FDR, stabilitas bootstrap, dan pruning; 1 di antaranya memuat item lingkungan spasial.
- Perbandingan dengan aturan tanpa item spasial: rata-rata lift 2.20 vs 2.14, rata-rata confidence 0.73 vs 0.71.
- Aturan terkuat R1: AirMinum=Rendah & RLS=Rendah => APS16-18=Rendah (support 0.135, confidence 0.706, lift 2.13, stabilitas 73%).
- Spatial Markov: peluang bertahan di kelas Rendah 0.88 saat tetangga lemah vs 0.79 saat tetangga kuat (uji LR p = 0.321).

## RQ3 Explainable forecasting
- Horizon 1 (2026): LightGBM | Base+Pattern, MAE 1.3498 vs persistence 1.5157, skill agregat +10.94%, Wilcoxon vs persistence p = 0.0089, interval 90% +/- 3.20 poin.
- Horizon 2 (2027): LightGBM | Base+Spatial, MAE 3.3690 vs persistence 3.5628, skill agregat +5.44%, Wilcoxon vs persistence p = 0.0019, interval 90% +/- 6.62 poin.
- Ablation LightGBM horizon 1: Base 1.3526, Base+Spatial 1.3838, Base+Pattern 1.3498, Full 1.3905.
- Ablation LightGBM horizon 2: Base 3.3926, Base+Spatial 3.3690, Base+Pattern 3.3897, Full 3.3764.
- Cakupan empiris interval 90% horizon 1 pada 2025: 60.5%.
- Porsi kepentingan SHAP: Sosial-ekonomi & pendidikan 84.5%, Spasial (Moran/LISA) 12.7%, Pola (aturan asosiasi) 2.7%.
- Tiga fitur terpenting 2026: Rumah Tangga Berlistrik (%), Penduduk Miskin (%), Indeks Ketahanan Pangan; 2027: Indeks Ketahanan Pangan, log Pengeluaran Makanan, Rumah Tangga Berlistrik (%).
- Rata-rata proyeksi nasional: 2026 78.65, 2027 79.25 (2025 aktual 76.75).

## RQ4 Triangulasi
- Provinsi Terjebak Struktural (tiga sinyal menyala): PAPUA PEGUNUNGAN, PAPUA SELATAN, PAPUA TENGAH, KALIMANTAN TENGAH, SUMATERA SELATAN, GORONTALO.
- Lima prioritas teratas IPI: PAPUA PEGUNUNGAN, PAPUA SELATAN, PAPUA TENGAH, KALIMANTAN TENGAH, SUMATERA SELATAN.
- Rata-rata Cohen's kappa antarsinyal: 0.425.

## Batasan
- Panel hanya 5 tahun dan 34-38 provinsi; seluruh uji memakai permutasi, bootstrap, dan validasi rolling-origin untuk mengimbanginya.
- SHAP, aturan asosiasi, dan simulasi skenario menunjukkan asosiasi, bukan hubungan sebab-akibat.
- Koordinat ibu kota adalah pendekatan lokasi provinsi; uji sensitivitas k dilakukan untuk memeriksa ketahanan hasil.